x = 100;
var x;
console.log(x);